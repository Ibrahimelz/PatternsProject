package org.example.view;

public class GUI {

}