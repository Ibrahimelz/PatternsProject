package org.example.model;

public enum SeatClass {
    ECONOMY, BUSINESS, FIRST_CLASS
}
