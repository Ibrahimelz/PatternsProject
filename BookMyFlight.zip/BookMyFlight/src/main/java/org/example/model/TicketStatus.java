package org.example.model;

public enum TicketStatus {
    UNBOOKED, BOOKED
}